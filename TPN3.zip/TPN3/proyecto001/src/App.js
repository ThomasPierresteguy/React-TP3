import './App.css';

function App() {
  return (
    <div>
      <form onSubmit={mostrarMensaje}>
        <p>Ingrese el mensaje:
          <input type="text" name="mensaje" />
        </p>
        <p>
          <input type="submit" value="Contar vocales" />
        </p>
      </form>
    </div>
  );
}

function contarVocales(mensaje) {
  let contador = 0;
    const vocales = ["a", "e", "i", "o", "u"];
    for (let i = 0; i < mensaje.length; i++) {
      if (vocales.includes(mensaje[i].toLowerCase())) {
      contador++;
    }
  }
  return contador;
}

function mostrarMensaje(e) {
  e.preventDefault();
  const msj = e.target.mensaje.value;
  const cantVocales = contarVocales(msj);
  alert('El mensaje tiene: '+cantVocales+' vocales');
}

export default App;